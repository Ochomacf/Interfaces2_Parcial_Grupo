
const express = require("express")
const path = require("path")

const app = express()
const PORT = 3000

// Sirve los archivos estáticos como JS, CSS, etc.
app.use(express.static(path.join(__dirname, "../frontend/dist")))

// Simula un principal
app.get("/principal", (req, res) => {
  // Aquí iría la lógica real de login
  res.sendFile(path.join(__dirname, "../frontend/dist/index.html")) 
})

// Simula un login
app.get("/login", (req, res) => {
  // Aquí iría la lógica real de login
  res.sendFile(path.join(__dirname, "../frontend/dist/index.html")) 
})

// Simula un adminstracion
app.get("/administracion", (req, res) => {
  // Aquí iría la lógica real de login
  res.sendFile(path.join(__dirname, "../frontend/dist/index.html")) 
})

// Simula un menu
app.get("/menu", (req, res) => {
  // Aquí iría la lógica real de login
  res.sendFile(path.join(__dirname, "../frontend/dist/index.html")) 
})

// Simula un reservas
app.get("/reservas", (req, res) => {
  // Aquí iría la lógica real de login
  res.sendFile(path.join(__dirname, "../frontend/dist/index.html")) 
})








app.post("/login", (req, res) => {
  // Aquí iría la lógica real de login
  console.log("Login recibido del post")
  res.sendStatus(200)
})

// Todas las demás rutas devuelven index.html
app.get("/formulario", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/dist/index.html"))
})

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`)
})