// src/components/Reservas/Reservas.jsx

import NavBar from '../Principal/NavBar';
import styles from './Reservas.module.css'; // Importa tus estilos CSS Modules

export default function Reservas() {
  // Por ahora, solo una función de manejo de envío vacía, sin lógica real de envío.
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log("Formulario de reservas enviado (sin lógica de envío al servidor aún).");
    // Aquí es donde eventualmente iría la lógica para enviar los datos
  };

  // Datos simulados para las mesas y horarios, esto vendrá de tu DB
  // Estas son solo para la interfaz, la lógica real de disponibilidad se implementará después.
  const floors = [
    { id: 'piso1', name: 'Primer Piso' },
    { id: 'piso2', name: 'Segundo Piso' },
  ];

  const tables = [
    { id: 'mesa1', name: 'Mesa 1', floor: 'piso1' },
    { id: 'mesa2', name: 'Mesa 2', floor: 'piso1' },
    { id: 'mesa3', name: 'Mesa 3', floor: 'piso1' },
    { id: 'mesa4', name: 'Mesa 4', floor: 'piso1' },
    { id: 'mesa5', name: 'Mesa 5', floor: 'piso1' },
    { id: 'mesa6', name: 'Mesa 6', floor: 'piso1' },
    { id: 'mesa7', name: 'Mesa 7', floor: 'piso1' },
    { id: 'mesa8', name: 'Mesa 8', floor: 'piso1' },
    { id: 'mesa9', name: 'Mesa 9', floor: 'piso1' },
    { id: 'mesa10', name: 'Mesa 10', floor: 'piso1' },
    { id: 'mesa11', name: 'Mesa 1', floor: 'piso2' },
    { id: 'mesa12', name: 'Mesa 2', floor: 'piso2' },
    { id: 'mesa13', name: 'Mesa 3', floor: 'piso2' },
    { id: 'mesa14', name: 'Mesa 4', floor: 'piso2' },
    { id: 'mesa15', name: 'Mesa 5', floor: 'piso2' },
    { id: 'mesa16', name: 'Mesa 6', floor: 'piso2' },
    { id: 'mesa17', name: 'Mesa 7', floor: 'piso2' },
    { id: 'mesa18', name: 'Mesa 8', floor: 'piso2' },
    { id: 'mesa19', name: 'Mesa 9', floor: 'piso2' },
    { id: 'mesa20', name: 'Mesa 10', floor: 'piso2' },
  ];

  // Horarios de ejemplo. En tu lógica real, estos dependerán de la mesa y la fecha.
  const availableTimes = ['19:00', '19:30', '20:00', '20:30', '21:00', '21:30'];
  
  return (
    <>
    <NavBar/>
    <main className={styles.reservasContainer}>
      <form onSubmit={handleSubmit} className={styles.reservasForm}>
        <h2 className={styles.formTitle}>Haz tu Reserva</h2>

        {/* Campo para la Fecha */}
        <div className={styles.inputGroup}>
          <label htmlFor="fecha" className={styles.label}>Fecha:</label>
          <input
            type="date"
            id="fecha"
            name="fecha"
            className={styles.inputField}
            required
          />
        </div>

        {/* Campo para el Número de Personas */}
        <div className={styles.inputGroup}>
          <label htmlFor="personas" className={styles.label}>Número de Personas:</label>
          <input
            type="number"
            id="personas"
            name="personas"
            min="1"
            max="10" // Puedes ajustar el máximo según tu restaurante
            defaultValue="2" // Valor por defecto
            className={styles.inputField}
            required
          />
        </div>

        {/* Nuevo Campo para Elegir el Piso */}
        <div className={styles.inputGroup}>
          <label htmlFor="piso" className={styles.label}>Elige el Piso:</label>
          <div className={styles.floorSelection}>
            {floors.map((floor) => (
              <label key={floor.id} className={styles.radioLabel}>
                <input
                  type="radio"
                  id={floor.id}
                  name="piso"
                  value={floor.id}
                  className={styles.radioInput}
                  // Aquí iría la lógica para manejar el cambio de piso
                />
                <span className={styles.radioCustom}></span>
                {floor.name}
              </label>
            ))}
          </div>
        </div>

        {/* Nuevo Campo para Elegir la Mesa (después de seleccionar el piso) */}
        {/* Usaremos un placeholder para las mesas del primer piso por defecto para la interfaz */}
        <div className={styles.inputGroup}>
          <label htmlFor="mesa" className={styles.label}>Elige tu Mesa:</label>
          <div className={styles.tableGrid}>
            {/* Iterar sobre las mesas (aquí podrías filtrar por el piso seleccionado) */}
            {tables.filter(table => table.floor === 'piso1').map((table) => ( // Ejemplo: mostrando solo mesas del primer piso
              <label key={table.id} className={styles.tableCard}>
                <input
                  type="radio"
                  id={table.id}
                  name="mesa"
                  value={table.id}
                  className={styles.tableRadioInput}
                  // Aquí iría la lógica para manejar la selección de mesa
                />
                <div className={styles.tableCardContent}>
                  <span className={styles.tableName}>{table.name}</span>
                  {/* <span className={styles.tableStatus}>Disponible</span> */}
                  {/* Aquí podrías añadir un indicador de estado de la mesa */}
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Sección para mostrar los Horarios Disponibles de la mesa elegida */}
        <div className={styles.inputGroup}>
          <label className={styles.label}>Horarios Disponibles:</label>
          {/* Este div se mostrará condicionalmente si hay una mesa seleccionada y horarios */}
          <div className={styles.availableTimesGrid}>
            {availableTimes.length > 0 ? (
              availableTimes.map((time) => (
                <label key={time} className={styles.timeSlot}>
                  <input
                    type="radio"
                    name="hora"
                    value={time}
                    className={styles.timeRadioInput}
                    required
                  />
                  <span className={styles.timeDisplay}>{time}</span>
                </label>
              ))
            ) : (
              <p className={styles.noTimesMessage}>No hay horarios disponibles para esta mesa y fecha.</p>
            )}
          </div>
        </div>


        {/* Campo para Notas/Comentarios adicionales */}
        <div className={styles.inputGroup}>
          <label htmlFor="notas" className={styles.label}>Notas Adicionales (opcional):</label>
          <textarea
            id="notas"
            name="notas"
            rows="4"
            placeholder="Ej. Preferencia de mesa, restricciones dietéticas..."
            className={`${styles.inputField} ${styles.textareaField}`} // Clases para input y textarea
          ></textarea>
        </div>

        {/* Botón de envío */}
        <button type="submit" className={styles.reservarButton}>Confirmar Reserva</button>
      </form>
    </main>
    </>
  );
}