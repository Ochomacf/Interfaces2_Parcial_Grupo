import NavBar from "../Principal/NavBar";
import styles from "./Menu.module.css";

export default function Menu() {
    const categories = [
        {
            name: "Platillos Principales",
            items: [
                { name: "Lomo Saltado", price: 45.00, description: "Clásico peruano con carne de res, papas y cebolla." },
                { name: "Ají de Gallina", price: 38.50, description: "Pollo deshilachado en salsa de ají amarillo y nueces." },
                { name: "Causa Rellena", price: 32.00, description: "Puré de papa amarilla con relleno de atún o pollo." },
                { name: "Arroz con Pato Norteño", price: 52.00, description: "Arroz verde con pato tierno y salsa criolla." },
                { name: "Tacu Tacu con Lomo", price: 48.00, description: "Frijoles y arroz fritos, acompañados de lomo." },
            ]
        },
        {
            name: "Bebidas Refrescantes",
            items: [
                { name: "Chicha Morada (Jarra)", price: 15.00, description: "Bebida tradicional de maíz morado." },
                { name: "Jugo de Maracuyá", price: 12.00, description: "Refrescante jugo natural de maracuyá." },
                { name: "Limonada Natural", price: 10.00, description: "Clásica limonada con un toque de hierbabuena." },
            ]
        },
        {
            name: "Licores y Cócteles",
            items: [
                { name: "Pisco Sour", price: 28.00, description: "El cóctel bandera del Perú, a base de pisco." },
                { name: "Chilcano de Pisco", price: 25.00, description: "Pisco, ginger ale y unas gotas de amargo de angostura." },
                { name: "Cerveza Cusqueña (Lager)", price: 18.00, description: "Cerveza peruana premium." },
                { name: "Vino Tinto (Copa)", price: 30.00, description: "Selección de vinos peruanos o importados." },
            ]
        },
        {
            name: "Postres",
            items: [
                { name: "Suspiro a la Limeña", price: 20.00, description: "Dulce tradicional de manjar blanco y merengue." },
                { name: "Mazamorra Morada", price: 18.00, description: "Postre de maíz morado, frutas y especias." },
            ]
        }
    ];

    return (
        <>
        <NavBar/>
        <div className={styles.menuContainer}>
            
            <header className={styles.menuHeader}>
                <h1 className={styles.menuTitle}>Nuestro Menú</h1>
                <p className={styles.menuSubtitle}>Delicias peruanas para cada paladar</p>
            </header>

            <main className={styles.menuContent}>
                {categories.map((category, index) => (
                    <section key={index} className={styles.menuCategory}>
                        <h2 className={styles.categoryTitle}>{category.name}</h2>
                        <ul className={styles.itemList}>
                            {category.items.map((item, itemIndex) => (
                                <li key={itemIndex} className={styles.menuItem}>
                                    <div className={styles.itemInfo}>
                                        <h3 className={styles.itemName}>{item.name}</h3>
                                        <p className={styles.itemDescription}>{item.description}</p>
                                    </div>
                                    <span className={styles.itemPrice}>S/. {item.price.toFixed(2)}</span>
                                </li>
                            ))}
                        </ul>
                    </section>
                ))}
            </main>

            <footer className={styles.menuFooter}>
                <p className={styles.footerText}>Precios en Soles Peruanos (S/). Incluye IGV.</p>
            </footer>
        </div>
        </>
    );
}