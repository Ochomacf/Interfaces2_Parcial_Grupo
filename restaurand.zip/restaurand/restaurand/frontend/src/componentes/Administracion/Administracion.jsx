import React from 'react';
import styles from "./Administracion.module.css";

export default function Administracion() {
    // Datos de ejemplo para las mesas y reservas (esto sería dinámico en tu aplicación)
    const mesasPorPiso = 10;
    const pisos = 2;

    const mesas = Array.from({ length: pisos }, (_, pisoIndex) =>
        Array.from({ length: mesasPorPiso }, (_, mesaIndex) => ({
            id: `P${pisoIndex + 1}M${mesaIndex + 1}`,
            numero: mesaIndex + 1,
            piso: pisoIndex + 1,
            reservas: [], // Aquí irían las reservas reales
            ocupacionesWalkIn: [], // Nuevas ocupaciones para clientes que llegan sin reserva
            estado: 'disponible', // 'disponible', 'no-disponible', 'ocupada' (temporalmente por walk-in)
            comentarioEstado: '', // Comentario para mesas no disponibles
        }))
    ).flat();

    // Simular algunas reservas y ocupaciones para la maqueta
    mesas[0].reservas = [
        {
            id: 'res1',
            horaInicio: '19:00',
            horaFin: '20:30',
            personas: 4,
            comentarios: 'Cumpleaños de María',
            tipo: 'reserva'
        },
        {
            id: 'res2',
            horaInicio: '21:00',
            horaFin: '22:30',
            personas: 2,
            comentarios: '',
            tipo: 'reserva'
        },
    ];

    mesas[0].ocupacionesWalkIn = [
        {
            id: 'walkin1',
            horaInicio: '18:00',
            horaFin: '18:45',
            personas: 3,
            comentarios: 'Clientes walk-in rápidos',
            tipo: 'walk-in'
        }
    ];

    mesas[1].estado = 'no-disponible';
    mesas[1].comentarioEstado = 'Fuga de agua en el techo. No usar hasta reparación.';

    mesas[10].reservas = [
        {
            id: 'res3',
            horaInicio: '18:30',
            horaFin: '20:00',
            personas: 6,
            comentarios: 'Mesa con vista a la calle',
            tipo: 'reserva'
        },
    ];

    const [mesaSeleccionada, setMesaSeleccionada] = React.useState(null);
    const [comentarioNoDisponible, setComentarioNoDisponible] = React.useState('');
    const [mostrarInputComentario, setMostrarInputComentario] = React.useState(false);


    const handleMesaClick = (mesa) => {
        setMesaSeleccionada(mesa);
        // Resetea el estado del comentario al seleccionar una nueva mesa
        setComentarioNoDisponible(mesa.comentarioEstado || '');
        setMostrarInputComentario(mesa.estado === 'no-disponible');
    };

    // Funciones placeholder para la lógica (vacías por ahora)
    const handleEliminarReserva = (reservaId) => {
        console.log(`Eliminar reserva: ${reservaId}`);
        // Aquí iría la lógica para eliminar la reserva
    };

    const handleEliminarOcupacionWalkIn = (ocupacionId) => {
        console.log(`Eliminar ocupación walk-in: ${ocupacionId}`);
        // Aquí iría la lógica para eliminar la ocupación
    };

    const handleOcuparHorario = () => {
        console.log("Abrir modal/formulario para ocupar horario por walk-in");
        // Aquí iría la lógica para agregar una ocupación
    };

    const handleToggleMesaEstado = () => {
        if (mesaSeleccionada) {
            const nuevoEstado = mesaSeleccionada.estado === 'no-disponible' ? 'disponible' : 'no-disponible';
            console.log(`Cambiando estado de Mesa ${mesaSeleccionada.numero} a: ${nuevoEstado}`);
            // La lógica para actualizar el estado de la mesa y guardar el comentario
            // (esto interactuaría con tu estado global o backend)

            // Para la UI, simplemente alterna el input del comentario
            setMostrarInputComentario(nuevoEstado === 'no-disponible');
            if (nuevoEstado === 'disponible') {
                setComentarioNoDisponible(''); // Limpiar comentario si se pone disponible
            }
        }
    };

    const handleGuardarComentarioEstado = () => {
        console.log(`Guardar comentario para Mesa ${mesaSeleccionada.numero}: ${comentarioNoDisponible}`);
        // Lógica para guardar el comentario de estado de la mesa
    };

    const allOccupations = mesaSeleccionada
        ? [...mesaSeleccionada.reservas, ...mesaSeleccionada.ocupacionesWalkIn].sort((a, b) => {
            // Ordenar por hora de inicio para visualización
            const timeA = parseInt(a.horaInicio.replace(':', ''));
            const timeB = parseInt(b.horaInicio.replace(':', ''));
            return timeA - timeB;
        })
        : [];

    return (
        <div className={styles.dashboardContainer}>
            <div className={styles.leftPanel}>
                <div className={styles.calendarContainer}>
                    <h3>Calendario</h3>
                    {/* Aquí iría un componente de calendario interactivo */}
                    <div className={styles.placeholderCalendar}>
                        <p>Calendario interactivo aquí</p>
                        <div className={styles.calendarGrid}>
                            <span>Lun</span><span>Mar</span><span>Mié</span><span>Jue</span><span>Vie</span><span>Sáb</span><span>Dom</span>
                            <span></span><span></span><span></span><span>1</span><span>2</span><span>3</span><span>4</span>
                            <span>5</span><span>6</span><span>7</span><span>8</span><span>9</span><span>10</span><span>11</span>
                            <span>12</span><span>13</span><span className={styles.currentDay}>14</span><span>15</span><span>16</span><span>17</span><span>18</span>
                            <span>19</span><span>20</span><span>21</span><span>22</span><span>23</span><span>24</span><span>25</span>
                            <span>26</span><span>27</span><span>28</span><span>29</span><span>30</span><span>31</span><span></span>
                        </div>
                    </div>
                </div>

                <div className={styles.mesaDetail}>
                    <h3>Detalles de la Mesa</h3>
                    {mesaSeleccionada ? (
                        <div className={styles.detailCard}>
                            <h4>Mesa {mesaSeleccionada.numero} - Piso {mesaSeleccionada.piso}</h4>
                            <p className={styles.mesaEstadoText}>
                                **Estado:** <span className={`${styles.statusBadge} ${styles[mesaSeleccionada.estado]}`}>
                                    {mesaSeleccionada.estado === 'disponible' && 'Disponible'}
                                    {mesaSeleccionada.estado === 'no-disponible' && 'No Disponible'}
                                </span>
                                {mesaSeleccionada.estado === 'no-disponible' && mesaSeleccionada.comentarioEstado && (
                                    <span className={styles.statusComment}> ({mesaSeleccionada.comentarioEstado})</span>
                                )}
                            </p>

                            <div className={styles.actionButtonsGroup}>
                                <button
                                    onClick={handleToggleMesaEstado}
                                    className={`${styles.actionButton} ${mesaSeleccionada.estado === 'no-disponible' ? styles.btnAvailable : styles.btnUnavailable}`}
                                >
                                    {mesaSeleccionada.estado === 'no-disponible' ? 'Marcar como Disponible' : 'Marcar como No Disponible'}
                                </button>

                                {mostrarInputComentario && mesaSeleccionada.estado === 'no-disponible' && (
                                    <div className={styles.commentInputContainer}>
                                        <textarea
                                            className={styles.commentTextarea}
                                            placeholder="Introduce un comentario (ej. 'Siniestro, fuga de agua')"
                                            value={comentarioNoDisponible}
                                            onChange={(e) => setComentarioNoDisponible(e.target.value)}
                                        />
                                        <button
                                            onClick={handleGuardarComentarioEstado}
                                            className={`${styles.actionButton} ${styles.btnSaveComment}`}
                                        >
                                            Guardar Comentario
                                        </button>
                                    </div>
                                )}
                            </div>

                            <hr className={styles.divider} />

                            <div className={styles.reservasOcupacionesSection}>
                                <h4>Reservas y Ocupaciones</h4>
                                {allOccupations.length > 0 ? (
                                    <div className={styles.occupationsList}>
                                        {allOccupations.map((item) => (
                                            <div key={item.id} className={`${styles.occupationItem} ${item.tipo === 'reserva' ? styles.reservaItem : styles.walkInItem}`}>
                                                <p>
                                                    <strong className={styles.occupationType}>{item.tipo === 'reserva' ? 'Reserva' : 'Walk-In'}:</strong> {item.horaInicio} - {item.horaFin}
                                                </p>
                                                <p><strong>Personas:</strong> {item.personas}</p>
                                                {item.comentarios && <p className={styles.occupationComment}><strong>Comentarios:</strong> {item.comentarios}</p>}
                                                <button
                                                    onClick={() => item.tipo === 'reserva' ? handleEliminarReserva(item.id) : handleEliminarOcupacionWalkIn(item.id)}
                                                    className={`${styles.deleteButton} ${styles.smallButton}`}
                                                >
                                                    &times;
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <p className={styles.noDataMessage}>No hay reservas ni ocupaciones para esta mesa en la fecha seleccionada.</p>
                                )}
                                <button
                                    onClick={handleOcuparHorario}
                                    className={`${styles.actionButton} ${styles.btnOccupyTime}`}
                                >
                                    Ocupar Horario (Walk-In)
                                </button>
                            </div>

                        </div>
                    ) : (
                        <p className={styles.noDataMessage}>Haz clic en una mesa para ver sus detalles.</p>
                    )}
                </div>
            </div>

            <div className={styles.rightPanel}>
                <h2>Mapa de Mesas</h2>
                <div className={styles.mapContainer}>
                    {Array.from({ length: pisos }, (_, pisoIndex) => (
                        <div key={`piso-${pisoIndex}`} className={styles.floor}>
                            <h3>Piso {pisoIndex + 1}</h3>
                            <div className={styles.mesasGrid}>
                                {mesas
                                    .filter((mesa) => mesa.piso === pisoIndex + 1)
                                    .map((mesa) => (
                                        <div
                                            key={mesa.id}
                                            className={`${styles.mesa} ${styles[mesa.estado]} ${mesaSeleccionada?.id === mesa.id ? styles.mesaSelected : ''}`}
                                            onClick={() => handleMesaClick(mesa)}
                                        >
                                            Mesa {mesa.numero}
                                            {mesa.reservas.length > 0 && (
                                                <span className={styles.reservaIndicator}>({mesa.reservas.length})</span>
                                            )}
                                            {mesa.estado === 'no-disponible' && (
                                                <span className={styles.unavailableIndicator}>🚫</span>
                                            )}
                                        </div>
                                    ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}