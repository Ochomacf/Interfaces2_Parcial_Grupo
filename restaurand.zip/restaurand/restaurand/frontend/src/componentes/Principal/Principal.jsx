// import styles from "./Principal.module.css"
import ContenidoPrincipal from "./ContenidoPrincipal"
import Footer from "./footer"
// import NavBar from "./navbar"
// este es  el que vale
export default function Principal(){


    return(
            <>
            <NavBar/>
            <ContenidoPrincipal/>
            <Footer/>
            </>
    )
}