import './NavBar.css'
import logo from '../../assets/logo.png'
const NavBar =()=>{
    return(
        <>
            <header className="NavBar">
                <figure className="NavBar-logo-titulo">
                    <img src={logo} alt="logo del resturante la huaca pucllana" className='logo'/>
                    <h1 className='title'>HUACA PUCLLANA</h1>
                </figure>
                <nav className="NavBar-nav">
                    <ul className='NavBar-nav-ul'>
                        <li className='navegacion'>Inicio</li>
                        <li className='navegacion'>La carta</li>
                        <li className='navegacion'>Login</li>
                    </ul>
                    
                </nav>
                <button className="NavBar-Button">Reservar</button>
            </header>
        </>

        
    )
}
export default NavBar