import "./ContenidoPrincipal.css"
import platillo1 from '../../assets/platillo1.jpg';
import platillo2 from '../../assets/platillo2.jpg';
import platillo3 from '../../assets/platillo3.jpg';
import platillo4 from '../../assets/platillo4.jpg';
import portada from '../../assets/portada.jpg';
const ContenidoPrincipal=()=>{
    return(
        <>
            <main>
                <section className="portada">
                    <img src={portada} alt="portada de bienvenida" />
                    <h2>BIENVENIDOS AL RESTAURANTE LA HUACA</h2>
                </section>
                <section>
                    <h3>Categorías Favoritas</h3>
                    <div className="platos">
                        <img src={platillo1} alt="platillo1" />
                        <img src={platillo2} alt="platillo2" />
                        <img src={platillo3} alt="platillo3" />
                        <img src={platillo4} alt="platillo4" />
                    </div>
                </section>
                
            </main>
        </>
    )
}
export default ContenidoPrincipal