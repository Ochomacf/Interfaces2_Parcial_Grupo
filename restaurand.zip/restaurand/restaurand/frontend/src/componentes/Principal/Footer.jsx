import './Footer.css'
const Footer=()=>{
    return (
        <>
            <footer>
                <section className='orden direccion'>
                    <h4>Dirección</h4>
                    <p>General Borgoño Cdra 8,Huaca Pucllana, Miraflores</p>
                </section>
                <section className='orden horarios'>
                    <h4>Horarios</h4>
                    <p>Lunes a Sábado 12:00pm - 10:00pm Domingos 12:00pm - 8:00pm</p>
                </section>
                <section className='orden contactanos'>
                    <h4>Contactanos</h4>
                    <address>
                        <p>(01) 445-4042 / 994-005-266</p>
                        <p>reservas@resthuacapucllana.com</p>
                    </address>
                </section>
                {/* <section>
                    <p>©2020 Restaurante Huaca Pucllana</p>
                    <nav>
                        <a href="#">f</a>
                        <a href="#">x</a>
                        <a href="#">t</a>
                    </nav>
                </section> */}
            </footer>
        </>
    )
}
export default Footer