// src/components/Login/Login.jsx

import styles from "./Login.module.css"; // Importa los estilos CSS Modules

export default function Login() {
  const handleSubmit = async (event) => {
    event.preventDefault();
    await fetch("/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user: "zero", password: "123456" })
    });

    window.location.href = "/administracion";
  };

  return (
    <main className={styles.loginContainer}> {/* Contenedor principal */}
      <form onSubmit={handleSubmit} className={styles.loginForm}> {/* Formulario */}
        <h2 className={styles.formTitle}>Iniciar Sesión</h2> {/* Título */}

        {/* Grupo de input para usua
        rio */}
        <div className={styles.inputGroup}> 
          <input name="user" placeholder="Usuario" className={styles.inputField} />
        </div>
        
        {/* Usamos un div para el salto de línea para mejor control del espaciado con CSS */}
        <div style={{ marginBottom: '20px' }}></div> {/* Espaciador, ya que <br/> no es ideal con flexbox */}

        {/* Grupo de input para contraseña */}
        <div className={styles.inputGroup}>
          <input name="password" type="password" placeholder="Contraseña" className={styles.inputField} />
        </div>

        {/* Usamos un div para el salto de línea para mejor control del espaciado con CSS */}
        <div style={{ marginBottom: '20px' }}></div> {/* Espaciador */}
        
        <button type="submit" className={styles.loginButton}>Entrar</button> {/* Botón */}
      </form>
    </main>
  );
}