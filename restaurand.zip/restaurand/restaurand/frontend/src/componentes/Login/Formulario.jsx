export default function Formulario() {
    return (
      <main>
        <h2>Formulario Seguro</h2>
        <p>Estás autenticado 👍</p>
        <form>
          <label>Tu nombre:</label><br />
          <input type="text" name="nombre" />
          <br /><br />
          <button type="submit">Enviar</button>
        </form>
      </main>
    )
  }